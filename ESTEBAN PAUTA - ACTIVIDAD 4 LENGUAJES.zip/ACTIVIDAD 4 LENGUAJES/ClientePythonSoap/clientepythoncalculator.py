from zeep import Client


client = Client('http://www.dneonline.com/calculator.asmx?WSDL')

#suma
result = client.service.Add(2, 6)
print('La suma es: ' + str(result))

#resta
result = client.service.Subtract(2, 6)
print('La resta es: ' + str(result))


#division
result = client.service.Divide(6, 2)
print('La division es: ' + str(result))


#multiplicacion
result = client.service.Multiply(2, 6)
print('La multiplicacion es: ' + str(result))

