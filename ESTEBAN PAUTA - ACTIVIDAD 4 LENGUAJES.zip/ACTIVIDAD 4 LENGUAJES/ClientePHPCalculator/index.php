<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $wsdl = 'http://www.dneonline.com/calculator.asmx?WSDL';

        $client = new SoapClient($wsdl);

        //suma
        $resultsuma = $client->Add(array('intA' => 5, 'intB' => 4));

        echo "El resultado de la suma es: $resultsuma->AddResult"."<br><br>";
        
        //resta
         $resultresta = $client->Subtract(array('intA' => 6, 'intB' => 5));

        echo "El resultado de la resta es: $resultresta->SubtractResult"."<br><br>";
        
        //multiplicacion
         $resultmultiplicacion = $client->Multiply(array('intA' => 2, 'intB' => 5));

        echo "El resultado de la multiplicacion es: $resultmultiplicacion->MultiplyResult"."<br><br>";
        
        //division
         $resultdivide = $client->Divide(array('intA' => 6, 'intB' => 3));

        echo "El resultado de la division es: $resultdivide->DivideResult"."<br><br>";
        ?>
    </body>
</html>
